fuser -k 8086/tcp
echo "8086 Port Killed and Starting NotificationService now..."


nohup java -Dlogging.config=/workspace/logConfig/notificationServiceLogConfig.xml -jar NotificationService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/NotificationService.out &

#nohup java -jar NotificationService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/NotificationService.out &
sleep 10
echo "NotificationService is up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
