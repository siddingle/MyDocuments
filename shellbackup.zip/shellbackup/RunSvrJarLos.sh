fuser -k 8181/tcp
fuser -k 8081/tcp
fuser -k 8082/tcp 
fuser -k 8083/tcp
fuser -k 8084/tcp
fuser -k 8085/tcp
fuser -k 8086/tcp
fuser -k 8080/tcp

echo "All Ports Killed and Starting Services now..."

echo "Starting NotificationService"
nohup java -jar NotificationService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_QA.properties -> startup-logs/NotificationService.out &
sleep 10

echo "Starting EmigrationService"
nohup java -jar EmigrantService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_QA.properties -> startup-logs/Emigration.out &
sleep 10

echo "Starting ForeignRecruiterService"
nohup java -jar ForeignRecruiterService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_QA.properties -> startup-logs/ForeignRecruiter.out &
sleep 10

echo "Starting ReportService"
nohup java -jar ReportService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_QA.properties -> startup-logs/Report.out &
sleep 10

echo "Starting RecruitingAgentService"
nohup java -jar RecruitingAgentService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_QA.properties -> startup-logs/RecruitingAgent.out &

echo "Starting MasterServiceService"
nohup java -jar MasterService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_QA.properties -> startup-logs/MasterService.out &

echo "Starting GatewayService"
nohup java -jar GatewayService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_QA.properties -> startup-logs/Gateway.out &

sleep 2
echo "All Services are up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
