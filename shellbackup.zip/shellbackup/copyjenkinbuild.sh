#!/bin/sh

current_user=$(whoami)
if [ "$current_user" == "root" ]
then
Module="$1"
FileName="$2"
buildn="$3"
run="$4"
env=services_UAT.properties

if [ $buildn -gt 0 ] 
then 
    echo "Download started for $Module-$buildn  :- $(date +%T)"
    pwd
   #  curl -u siddharth.ingle:11fb5fd3766920ced86f67c0df83ef2f1c https://apps.trigyn.com/jenkins2/job/$Module/$buildn/artifact/SvrJsbJarFdr/$FileName --output $FileName
    curl http://192.168.150.8:8080/job/$Module/$buildn/artifact/SvrJsbJarFdr/$FileName --output $FileName
    echo "Download completed :- $(date +%T)"
    file_size=$(stat -c %s "$FileName")
         file_size_mb=$((file_size / 1024 / 1024))
         echo "file_size= ${file_size}"
         echo "${FileName} file_size in mb= ${file_size_mb}"

    if [ ${file_size_mb} -gt 30 ]; then

#   echo "Download started for $env"
#   curl http://192.168.150.8:8080/job/$Module/$buildn/artifact/$env --output $env
#   echo "Download completed for $env :- $(date +%T)"
    cd ..
    pwd

    mkdir -p backup/$(date +%Y-%m-%d)
    echo "Backup Started for $env :- $(date +%T)"
    cp -pr  $env backup/$(date +%Y-%m-%d)
    echo "Backup Completed :- $(date +%T)"

    pwd
    echo "Backup Started for $Module :- $(date +%T)"
    cp -pr  $FileName backup/$(date +%Y-%m-%d)/
    echo "Backup Completed :- $(date +%T)" 
    
    echo "New Build and $env  will be added in 3 seconds"
    cp newbuild/$FileName .
#    cp newbuild/$env .
    echo "new Build and $env Added into packages :- $(date +%T)"

    if [ $Module == EMigrate-IntegrationService ]; then
    echo "Sending Integration Service to batch"
#   cp batch/$env batch/backup/
    cp -pr batch/$FileName batch/backup/
#   cp newbuild/$env batch/
    cp newbuild/$FileName batch/
   else
    echo "Build is copied from jenkins"

    echo "Starting Services in 5 sec"
    sleep 5
    sh $run
    echo "$Module is started"
#   sleep 5
   fi
   else
    echo "File size is not greater than 30MB, Exited Script"
   fi
    
else

    echo "Download started for $Module-lastSuccessfulBuild :- $(date +%T)"
    pwd
   #  curl -u siddharth.ingle:11fb5fd3766920ced86f67c0df83ef2f1c https://apps.trigyn.com/jenkins2/job/$Module/lastSuccessfulBuild/artifact/SvrJsbJarFdr/$FileName --output $FileName
    curl http://192.168.150.8:8080/job/$Module/lastSuccessfulBuild/artifact/SvrJsbJarFdr/$FileName --output $FileName
    echo "Download completed :- $(date +%T)"
    
    file_size=$(stat -c %s "$FileName")
         file_size_mb=$((file_size / 1024 / 1024))
         echo "file_size= ${file_size}"
         echo "${FileName} file_size in mb= ${file_size_mb}"

    if [ ${file_size_mb} -gt 30 ]; then

#   echo "Downlload started for $env"
#   curl http://192.168.150.8:8080/job/$Module/lastSuccessfulBuild/artifact/$env --output $env
#   echo "Download completed for $env :- $(date +%T)"
    cd ..

    pwd

    mkdir -p backup/$(date +%Y-%m-%d)
    echo "Backup Started for $env :- $(date +%T)"
    cp -pr  $env backup/$(date +%Y-%m-%d)
    echo "Backup Completed :- $(date +%T)"

    pwd
    echo "Backup Started for $Module :- $(date +%T)"
    cp -pr $FileName backup/$(date +%Y-%m-%d)
    echo "Backup Completed :- $(date +%T)"

    echo "New Build and $env  will be added in 3 seconds"
    cp newbuild/$FileName .
#   cp newbuild/$env .
    echo "new Build and $env Added into packages :- $(date +%T)"
    

    if [ $Module == EMigrate-IntegrationService ]; then
    echo "Sending Integration Service to batch"
 #   cp batch/$env batch/backup/
    cp -pr batch/$FileName batch/backup/
 #   cp newbuild/$env batch/
    cp newbuild/$FileName batch/
   else
    echo "Build is copied from jenkins"

    echo "Starting Services in 5 sec"
    sleep 5
    sh $run
#   sleep 5
    echo "$Module is started"
   fi
   else
    echo "File size is not greater than 30MB, Exited Script"
   fi

    
fi
else
	echo "Exited this shell [1--> Only meauser can run this script]"

fi











