./1RunSvrJarGateway-api.sh
sleep 5
./2RunSvrJarAdmin.sh
sleep 5
./3RunSvrJarAuthentication.sh
sleep 5
./4RunSvrJarSecurity.sh
sleep 5
./5RunSvrJarWorkflow.sh
sleep 5
./6RunSvrJarEmigrant.sh
sleep 5
./7RunSvrJarForeignEmployer.sh
sleep 5
./8RunSvrJarRecruitAgent.sh
sleep 5
./9RunSvrJarNotification.sh
sleep 5
./10RunSvrJarReport.sh
sleep 5
./12RunSvrJarGrievanceService.sh
sleep 5
./14RunSvrJarPayment.sh
sleep 5
./15RunSvrJarInsurance.sh
