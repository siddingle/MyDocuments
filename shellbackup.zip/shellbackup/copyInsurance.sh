#!/bin/sh

Module=EMigrate-InsuranceService
FileName=InsuranceService-0.0.1-SNAPSHOT.jar
buildn="$1"
run=15RunSvrJarInsurance.sh
if [ $buildn -gt 0 ]
then
   echo "Copy $Module $FileName $buildn"
   ./copyjenkinbuild.sh $Module $FileName $buildn $run
else
   echo "Copy $Module $FileName latestBuild "
   ./copyjenkinbuild.sh $Module $FileName $run
fi










