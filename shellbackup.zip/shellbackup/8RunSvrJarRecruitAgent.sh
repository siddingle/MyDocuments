fuser -k 8082/tcp
echo "8082 Port Killed and Starting RecruitingAgentService now..."


nohup java -Dlogging.config=/workspace/logConfig/recruitingAgentServiceLogConfig.xml -jar RecruitingAgentService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/RecruitingAgent.out &

#nohup java -jar RecruitingAgentService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/RecruitingAgent.out &
sleep 10
echo "RecruitingAgent Service is up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
