fuser -k 8083/tcp
echo "8083 Port Killed and Starting ForeignRecruiterService now..."


nohup java -Dlogging.config=/workspace/logConfig/foreignRecruiterServiceLogConfig.xml -jar ForeignRecruiterService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/ForeignRecruiter.out &

#nohup java -jar ForeignRecruiterService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/ForeignRecruiter.out &
sleep 10
echo "ForeignRecruiterService are up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
