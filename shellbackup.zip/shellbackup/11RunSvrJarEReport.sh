fuser -k 8089/tcp
echo "8089 Port Killed and Starting Service now..."
echo "Starting EReportService"
# -Xdebug -Xrunjdwp:server=y,transport=dt_socket,address=*:8000,suspend=n
nohup java -jar EReportService-0.0.1-SNAPSHOT.jar --spring.config.location=/home/migration/emigrate/server/packages/eReport/application.yml --spring.config.additional-location=services_UAT.properties -> startup-logs/EReportService.out &
sleep 2
echo "EReport Service is up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
