#!/bin/sh

Module=EMigrate-IntegrationService
FileName=IntegrationService-0.0.1-SNAPSHOT.jar
buildn="$1"
if [ $buildn -gt 0 ]
then
   echo "Copy $Module $FileName $buildn"
   ./copyjenkinbuild.sh $Module $FileName $buildn
else
   echo "Copy $Module $FileName latestBuild "
   ./copyjenkinbuild.sh $Module $FileName
fi










