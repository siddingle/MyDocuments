fuser -k 8088/tcp

echo "8088 Port Killed and Starting Services now..."

echo "Starting WorkflowService"


nohup java -Dlogging.config=/workspace/logConfig/workflowServiceLogConfig.xml -jar WorkflowService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/WorkflowService.out &



#nohup java -jar WorkflowService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/WorkflowService.out &

sleep 2
echo "Workflow Services are up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
