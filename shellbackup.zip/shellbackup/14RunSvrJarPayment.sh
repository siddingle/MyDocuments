fuser -k 8094/tcp
echo "8094 Port Killed and Starting PaymentService now..."


nohup java -Dlogging.config=/workspace/logConfig/paymentServiceLogConfig.xml -jar PaymentService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/PaymentService.out &

#nohup java -jar PaymentService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/PaymentService.out &
sleep 10
echo "PaymentService are up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"

