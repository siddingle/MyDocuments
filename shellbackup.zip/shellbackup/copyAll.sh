./copyAdmin.sh
sleep 5
./copyAuthnetication.sh
sleep 5
./copyEC.sh
sleep 5
./copyFE.sh
sleep 5
./copyGateway.sh
sleep 5
./copyGrievance.sh
sleep 5
./copyInsurance.sh
sleep 5
./copyIntegration.sh
sleep 5
./copyNotification.sh
sleep 5
./copyPayment.sh
sleep 5
./copyRA.sh
sleep 5
./copyReport.sh
sleep 5
./copySecurity.sh
sleep 5
./copyWorkflow.sh
