fuser -k 8085/tcp
echo "8085 Port Killed and Starting Service now..."
echo "Starting ReportService"


nohup java -Dlogging.config=/workspace/logConfig/reportServiceLogConfig.xml -jar ReportService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/ReportService.out &

#nohup java -jar ReportService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/ReportService.out &
sleep 2
echo "Report Service is up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
