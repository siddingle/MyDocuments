fuser -k 8084/tcp
echo "8084 Port Killed and Starting EmigrationService now..."


nohup java -Dlogging.config=/workspace/logConfig/emigrantServiceLogConfig.xml -jar EmigrantService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/Emigration.out &

#nohup java -jar EmigrantService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/Emigration.out &
sleep 10
echo "Emigration Service is up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
