fuser -k 8181/tcp

echo "8181 Port Killed and Starting Services now..."

echo "Starting AuthenticationService"


nohup java -Dlogging.config=/workspace/logConfig/authenticationServiceLogConfig.xml -jar AuthenticationService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/AuthenticationService.out &

#nohup java -jar AuthenticationService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/AuthenticationService.out &

sleep 2
echo "Authentication Services are up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
