fuser -k 8080/tcp
echo "8080 Port Killed and Starting GatewayService now..."

nohup java -Dlogging.config=/workspace/logConfig/gatewayServiceLogConfig.xml -jar GatewayService-0.0.1-SNAPSHOT.jar --spring.config.location=application_m.properties  --spring.config.additional-location=services_UAT.properties -> startup-logs/Gateway.out &


#nohup java -jar GatewayService-0.0.1-SNAPSHOT.jar --spring.config.location=application_m.properties  --spring.config.additional-location=services_UAT.properties -> startup-logs/Gateway.out &
sleep 5
echo "GatewayService is up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
