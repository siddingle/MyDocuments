fuser -k 8093/tcp

echo "8093 Port Killed and Starting Services now..."

echo "Starting DocumentServerService"


nohup java -Dlogging.config=/workspace/logConfig/documentServerLogConfig.xml -jar DocumentServerService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/DocumentServerService.out &

#nohup java -jar DocumentServerService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/DocumentServerService.out &

sleep 2
echo "DocumentServer Services are up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"

