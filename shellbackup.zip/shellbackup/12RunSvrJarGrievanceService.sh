fuser -k 8092/tcp
echo "8092 Port Killed and Starting GrievanceService now..."


nohup java -Dlogging.config=/workspace/logConfig/grievanceServiceLogConfig.xml -jar GrievanceService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/GrievanceService.out &

#nohup java -jar GrievanceService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/GrievanceService.out &
sleep 10
echo "GrievanceService are up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"


