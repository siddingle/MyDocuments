fuser -k 8080/tcp
fuser -k 8081/tcp
fuser -k 8181/tcp
fuser -k 8082/tcp
fuser -k 8083/tcp
fuser -k 8084/tcp
fuser -k 8085/tcp
fuser -k 8086/tcp
fuser -k 8087/tcp
fuser -k 8088/tcp
fuser -k 8090/tcp
fuser -k 8091/tcp
fuser -k 8092/tcp
fuser -k 8093/tcp
fuser -k 8094/tcp
fuser -k 8096/tcp

