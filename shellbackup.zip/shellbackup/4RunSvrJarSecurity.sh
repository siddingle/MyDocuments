fuser -k 8087/tcp

echo "8087 Port Killed and Starting Services now..."

echo "Starting SecurityService"


nohup java -Dlogging.config=/workspace/logConfig/securityServiceLogConfig.xml -jar SecurityService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/SecurityService.out &

#nohup java -jar SecurityService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties -> startup-logs/SecurityService.out &

sleep 2
echo "Security Services are up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"
