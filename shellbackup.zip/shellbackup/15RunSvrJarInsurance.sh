fuser -k 8096/tcp

echo "8096 Port Killed and Starting Services now..."

echo "Starting InsuranceService"


nohup java -Dlogging.config=/workspace/logConfig/insuranceServiceLogConfig.xml -jar InsuranceService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties  -> startup-logs/InsuranceService.out &

#nohup java -jar InsuranceService-0.0.1-SNAPSHOT.jar --spring.config.additional-location=services_UAT.properties  -> startup-logs/InsuranceService.out &

sleep 2
echo "Insurance Services are up and running... Kindly Check startup-logs for startup Logs, api logs shall be available @ ../../logs"

