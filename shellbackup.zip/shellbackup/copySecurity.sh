#!/bin/sh

Module=EMigrate-SecurityService
FileName=SecurityService-0.0.1-SNAPSHOT.jar
buildn="$1"
run=4RunSvrJarSecurity.sh
if [ $buildn -gt 0 ]
then
   echo "Copy $Module $FileName $buildn"
   ./copyjenkinbuild.sh $Module $FileName $buildn $run
else
   echo "Copy $Module $FileName latestBuild "
   ./copyjenkinbuild.sh $Module $FileName $run
fi












